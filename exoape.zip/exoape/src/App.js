import './shared.css';  // Import global shared styles
import './fonts.css';   // Import global font styles
import { useState, useEffect } from "react";  // Import React hooks for managing state and side effects
import Lenis from '@studio-freight/lenis';  // Import Lenis library for smooth scrolling

import Home from "./Components/Home/Home";  // Import Home component
import LoadingScreen from "./Components/LoadingScreen/LoadingScreen";  // Import LoadingScreen component
import CursorIcon from './Components/CursorIcon/CursorIcon';  // Import custom cursor icon component

const App = () => {

  // State to manage loading screen visibility. Initially set to true (show loading screen).
  const [loadingVisible, setLoadingVisible] = useState(true);

  /**
   * useEffect to create a custom cursor icon.
   * This code runs once when the component mounts.
   * The CursorIcon function creates and initializes the custom cursor behavior.
   */
  useEffect(() => { 
    new CursorIcon();  // Initializes custom cursor when the component is first loaded
  }, []);  // Empty dependency array means this runs only when the component is mounted

  /**
   * useEffect to set up smooth scrolling after a delay.
   * The Lenis library is used to make the page scroll smoothly.
   * The setTimeout delays the activation of smooth scrolling until the loading screen is finished.
   */
  useEffect(() => {
    setTimeout(() => {  // Delay the scroll setup by 3800ms (after loading screen disappears)
      const lenis = new Lenis({
        lerp: 0.1,  // Sets how smooth the scrolling should be (0.1 means quite smooth)
        smooth: true,  // Enables smooth scrolling behavior
      });

      // This function is called every animation frame to make scrolling smooth
      const scrollFn = () => {
        lenis.raf();  // Calls the Lenis rendering function each frame
        requestAnimationFrame(scrollFn);  // Continuously requests the next animation frame
      };
      requestAnimationFrame(scrollFn);  // Start the animation frame loop for smooth scrolling
    }, 3800);  // 3800ms delay before enabling smooth scrolling (after loading is finished)
  }, []);  // Empty array means this effect runs only when the component is mounted

  return (
    <div className="center column">
      {/* Conditionally render the LoadingScreen component if loadingVisible is true */}
      {loadingVisible ? (
        <LoadingScreen setLoadingVisible={setLoadingVisible} />  // Pass down the state setter to LoadingScreen to hide it after loading
      ) : null}
      
      {/* Render the Home component after loading is done */}
      <Home />  
    </div>
  );
};

export default App;
